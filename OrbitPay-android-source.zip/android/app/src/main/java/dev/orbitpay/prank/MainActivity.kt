package dev.orbitpay.prank

import android.content.Context
import android.content.SharedPreferences
import android.graphics.Bitmap
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TextField
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.FilterQuality
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.hapticfeedback.HapticFeedback
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import com.google.zxing.BarcodeFormat
import com.google.zxing.qrcode.QRCodeWriter
import java.util.Calendar
import kotlin.math.roundToInt
import kotlin.random.Random
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/**
 * Orbit Pay: розыгрыш-имитация терминала. Деньги не списываются.
 * Надпись «пранк-терминал, не настоящий» и пометка в финале нужны всегда и не отключаются.
 */
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        WindowInsetsControllerCompat(window, window.decorView).apply {
            hide(WindowInsetsCompat.Type.systemBars())
            systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        }
        setContent { OrbitPayApp() }
    }
}

enum class Phase { Idle, Scan, Request, Waiting, Charging, Done }

enum class Method(val title: String, val hint: String) {
    Card("Карта", "Коснитесь экрана для оплаты"),
    Smile("Улыбка", "Коснитесь и улыбнитесь"),
    Qr("QR", "Коснитесь, когда QR отсканируют"),
}

enum class Fake { Reboot, Update, Offline }

val themes: List<Pair<String, List<Color>>> = listOf(
    "Космос" to listOf(Color(0xFF0A0A29), Color(0xFF471F80)),
    "Океан" to listOf(Color(0xFF001F4D), Color(0xFF008099)),
    "Закат" to listOf(Color(0xFF4D0D40), Color(0xFFF27394)),
    "Мята" to listOf(Color(0xFF1A8C66), Color(0xFF8CE6B3)),
    "Лес" to listOf(Color(0xFF05261A), Color(0xFF1A7340)),
    "Ночь" to listOf(Color(0xFF050509), Color(0xFF262633)),
)

val currencies = listOf("₽", "$", "€", "₸", "₴", "Br")

// Любой финал содержит явное указание, что это розыгрыш.
val jokes = listOf(
    "Оплата успешна…\nшутка, это пранк",
    "Это был пранк\nДеньги никуда не ушли",
    "Недостаточно мемов на карте\nпранк",
    "Транзакция одобрена\nмамой, но не банком (пранк)",
)
val smileJokes = listOf(
    "Улыбка распознана\nСтоимость: один анекдот (пранк)",
    "Улыбка принята, оплата нет\nэто пранк",
)
val qrJokes = listOf(
    "QR-код оказался\nрецептом борща (пранк)",
    "QR отсканирован\nи отправлен в рофл (пранк)",
)
val failTexts = listOf(
    "Карта заблокирована\nобратитесь к маме (пранк)",
    "Ошибка 418\nя чайник (пранк)",
    "Банк в отпуске\nпопробуйте позже (пранк)",
)

class Settings(private val sp: SharedPreferences) {
    var amount by mutableStateOf(sp.getString("amount", "199") ?: "199")
    var currency by mutableStateOf(sp.getString("currency", "₽") ?: "₽")
    var theme by mutableIntStateOf(sp.getInt("theme", 0))
    var mode by mutableIntStateOf(sp.getInt("mode", 0))
    var method by mutableIntStateOf(sp.getInt("method", 0))
    var speed by mutableFloatStateOf(sp.getFloat("speed", 1f))
    var hold by mutableFloatStateOf(sp.getFloat("hold", 0f))
    var stars by mutableStateOf(sp.getBoolean("stars", true))
    var haptics by mutableStateOf(sp.getBoolean("haptics", true))
    var sound by mutableStateOf(sp.getBoolean("sound", true))

    val amountValue: Long get() = amount.filter { it.isDigit() }.take(12).toLongOrNull() ?: 0L

    fun save() {
        sp.edit()
            .putString("amount", amount).putString("currency", currency)
            .putInt("theme", theme).putInt("mode", mode).putInt("method", method)
            .putFloat("speed", speed).putFloat("hold", hold)
            .putBoolean("stars", stars).putBoolean("haptics", haptics).putBoolean("sound", sound)
            .apply()
    }

    fun reset() {
        amount = "199"; currency = "₽"; theme = 0; mode = 0; method = 0
        speed = 1f; hold = 0f; stars = true; haptics = true; sound = true
        save()
    }
}

/** 1500 -> «1 500» (узкий неразрывный пробел между разрядами). */
fun group(n: Long): String {
    val sb = StringBuilder()
    n.toString().reversed().forEachIndexed { i, c ->
        if (i > 0 && i % 3 == 0) sb.append(' ')
        sb.append(c)
    }
    return sb.reverse().toString()
}

fun makeQr(): ImageBitmap {
    val alphabet = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"
    val code = (1..16).map { alphabet.random() }.joinToString("")
    val m = QRCodeWriter().encode("ORBIT-PRANK-$code", BarcodeFormat.QR_CODE, 0, 0)
    val bmp = Bitmap.createBitmap(m.width, m.height, Bitmap.Config.ARGB_8888)
    for (x in 0 until m.width) for (y in 0 until m.height) {
        bmp.setPixel(x, y, if (m[x, y]) 0xFF000000.toInt() else 0xFFFFFFFF.toInt())
    }
    return bmp.asImageBitmap()
}

fun beep(ok: Boolean) {
    try {
        ToneGenerator(AudioManager.STREAM_MUSIC, 70)
            .startTone(if (ok) ToneGenerator.TONE_PROP_ACK else ToneGenerator.TONE_PROP_NACK, 180)
    } catch (_: Exception) {
    }
}

@Composable
fun OrbitPayApp() {
    val ctx = LocalContext.current
    val s = remember { Settings(ctx.getSharedPreferences("orbitpay", Context.MODE_PRIVATE)) }
    var splash by remember { mutableStateOf(true) }
    val scope = rememberCoroutineScope()
    LaunchedEffect(Unit) { delay(2600); splash = false }

    Box(Modifier.fillMaxSize().background(Color.Black)) {
        Terminal(s, interactive = !splash, onReboot = {
            scope.launch { splash = true; delay(2600); splash = false }
        })
        AnimatedVisibility(visible = splash, enter = fadeIn(tween(200)), exit = fadeOut(tween(500))) {
            Splash()
        }
    }
}

@Composable
fun Splash() {
    val p = remember { Animatable(0f) }
    LaunchedEffect(Unit) { p.animateTo(1f, tween(1500, easing = FastOutSlowInEasing)) }
    Box(Modifier.fillMaxSize().background(Color.Black), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Canvas(Modifier.size(200.dp)) {
                for (i in 0..2) {
                    val r = (35 + i * 23).dp.toPx()
                    drawArc(
                        color = Color.White.copy(alpha = 0.85f - i * 0.2f),
                        startAngle = -90f + i * 140f * p.value,
                        sweepAngle = 360f * p.value,
                        useCenter = false,
                        topLeft = Offset(center.x - r, center.y - r),
                        size = Size(2 * r, 2 * r),
                        style = Stroke(2.5.dp.toPx(), cap = StrokeCap.Round),
                    )
                }
                drawCircle(Color.White, radius = 9.dp.toPx() * p.value, center = center)
            }
            Spacer(Modifier.height(24.dp))
            Text("Orbit Pay", color = Color.White.copy(alpha = p.value), fontSize = 30.sp, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
fun Terminal(s: Settings, interactive: Boolean, onReboot: () -> Unit) {
    val haptic = LocalHapticFeedback.current
    val scope = rememberCoroutineScope()
    val method = Method.entries[s.method.coerceIn(0, Method.entries.size - 1)]

    var phase by remember { mutableStateOf(Phase.Idle) }
    var failed by remember { mutableStateOf(false) }
    var willFail by remember { mutableStateOf(false) }
    var joke by remember { mutableStateOf(jokes[0]) }
    var ringRed by remember { mutableStateOf(false) }
    var chargeLabel by remember { mutableStateOf("оплата") }
    var pop by remember { mutableStateOf(false) }
    var fake by remember { mutableStateOf<Fake?>(null) }
    var fakeProgress by remember { mutableFloatStateOf(0f) }
    var showSettings by remember { mutableStateOf(false) }
    var logoTaps by remember { mutableIntStateOf(0) }
    var lastTap by remember { mutableLongStateOf(0L) }
    var qr by remember { mutableStateOf<ImageBitmap?>(null) }
    var drag by remember { mutableFloatStateOf(0f) }
    val ring = remember { Animatable(0f) }
    val counter = remember { Animatable(0f) }
    val shake = remember { Animatable(0f) }

    // QR меняется каждые 4 секунды, пока терминал ждёт оплату.
    LaunchedEffect(method, phase) {
        if (method == Method.Qr && phase == Phase.Idle) {
            while (true) {
                qr = makeQr()
                delay(4000)
            }
        } else if (qr == null) {
            qr = makeQr()
        }
    }

    fun tick(type: HapticFeedbackType = HapticFeedbackType.LongPress) {
        if (s.haptics) haptic.performHapticFeedback(type)
    }

    fun start() {
        if (phase != Phase.Idle) return
        scope.launch {
            val k = 1f / s.speed
            val jit = 0.9f + Random.nextFloat() * 0.35f
            suspend fun wait(sec: Float) = delay((sec * 1000 * k).toLong())

            willFail = s.mode == 1
            failed = false; ringRed = false; chargeLabel = "оплата"; pop = false
            ring.snapTo(0f); counter.snapTo(0f)
            tick()

            if (method == Method.Card) {
                phase = Phase.Request
                wait(1.6f * jit)
            } else {
                phase = Phase.Scan
                wait(1.7f)
                pop = true
                tick(HapticFeedbackType.TextHandleMove)
                wait(0.7f)
                phase = Phase.Request
                wait(1.6f * jit)
            }
            phase = Phase.Waiting
            wait(1.2f * jit)
            phase = Phase.Charging

            if (willFail) {
                // Списание начинается, зависает на полпути и обрывается ошибкой.
                counter.snapTo(s.amountValue.toFloat())
                ring.animateTo(0.25f + Random.nextFloat() * 0.4f, tween((900 * k).toInt()))
                wait(0.3f)
                ringRed = true
                chargeLabel = "ошибка"
                tick()
                launch {
                    repeat(8) { shake.animateTo(12f, tween(70)); shake.animateTo(-12f, tween(70)) }
                    shake.animateTo(0f, tween(70))
                }
                wait(1.8f + s.hold)
            } else {
                launch { counter.animateTo(s.amountValue.toFloat(), tween((1200 * k).toInt())) }
                ring.animateTo(1f, tween((1200 * k).toInt()))
                wait(0.1f + s.hold)
            }

            failed = willFail
            val pool = jokes + when (method) {
                Method.Smile -> smileJokes
                Method.Qr -> qrJokes
                else -> emptyList()
            }
            joke = if (failed) failTexts.random() else pool.random()
            if (s.sound) beep(!failed)
            tick()
            phase = Phase.Done
        }
    }

    fun runFake(kind: Fake) {
        tick()
        fakeProgress = 0f
        fake = kind
        scope.launch {
            when (kind) {
                Fake.Reboot -> { delay(1400); fake = null; onReboot() }
                Fake.Update -> {
                    var p = 0f
                    while (p < 1f) {
                        delay(150)
                        p = minOf(1f, p + 0.004f + Random.nextFloat() * 0.026f)
                        fakeProgress = p
                    }
                    delay(600)
                    fake = null
                    onReboot()
                }
                Fake.Offline -> {}
            }
        }
    }

    fun logoTap() {
        val now = System.currentTimeMillis()
        logoTaps = if (now - lastTap < 1200) logoTaps + 1 else 1
        lastTap = now
        if (logoTaps >= 5) {
            logoTaps = 0
            tick()
            showSettings = true
        }
    }

    Box(
        Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(themes[s.theme.coerceIn(0, themes.size - 1)].second))
            .pointerInput(phase) {
                detectHorizontalDragGestures(
                    onDragStart = { drag = 0f },
                    onDragEnd = {
                        // Свайп влево/вправо листает способ оплаты.
                        if (phase == Phase.Idle && fake == null && kotlin.math.abs(drag) > 120f) {
                            val n = Method.entries.size
                            s.method = (s.method + (if (drag < 0) 1 else n - 1)) % n
                            s.save()
                        }
                    },
                ) { _, amount -> drag += amount }
            }
            .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) {
                if (!interactive || fake != null) return@clickable
                if (phase == Phase.Idle) start() else if (phase == Phase.Done) phase = Phase.Idle
            },
    ) {
        if (s.stars) Stars()

        Column(
            Modifier.fillMaxSize().safeDrawingPadding().padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Text(
                "Orbit Pay",
                color = Color.White.copy(alpha = 0.95f),
                fontSize = 22.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier
                    .padding(top = 12.dp)
                    .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { logoTap() }
                    .padding(horizontal = 20.dp, vertical = 6.dp),
            )
            Text("пранк-терминал, не настоящий", color = Color.White.copy(alpha = 0.7f), fontSize = 13.sp)
            Spacer(Modifier.weight(1f))

            Box(Modifier.offset { IntOffset(shake.value.roundToInt(), 0) }, contentAlignment = Alignment.Center) {
                when (phase) {
                    Phase.Idle -> IdleView(s, method, qr)
                    Phase.Scan -> Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        ScanBox(method, qr, pop)
                        Spacer(Modifier.height(22.dp))
                        Text(
                            if (method == Method.Smile) "Улыбнитесь в камеру" else "QR-код считан…",
                            color = Color.White.copy(alpha = 0.9f), fontSize = 16.sp,
                        )
                    }
                    Phase.Request -> Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Spinner()
                        Spacer(Modifier.height(20.dp))
                        Text("Передаю запрос…", color = Color.White.copy(alpha = 0.9f), fontSize = 16.sp)
                    }
                    Phase.Waiting -> Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Dots()
                        Spacer(Modifier.height(28.dp))
                        Text(
                            if (willFail) "Банк не отвечает…" else "Жду ответа…",
                            color = Color.White.copy(alpha = 0.9f), fontSize = 16.sp,
                        )
                    }
                    Phase.Charging -> ChargingRing(
                        progress = ring.value,
                        red = ringRed,
                        text = group(counter.value.toLong()) + " " + s.currency,
                        label = chargeLabel,
                    )
                    Phase.Done -> DoneView(failed, joke)
                }
            }

            Spacer(Modifier.weight(1f))
            if (phase == Phase.Idle) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("Демо-режим", color = Color.White.copy(alpha = 0.5f), fontSize = 11.sp)
                    val c = Calendar.getInstance()
                    Text(
                        "%02d:%02d".format(c.get(Calendar.HOUR_OF_DAY), c.get(Calendar.MINUTE)),
                        color = Color.White.copy(alpha = 0.5f), fontSize = 11.sp,
                    )
                }
            }
        }

        // Три невидимые зоны внизу: перезагрузка, обновление, нет связи.
        if (interactive && phase == Phase.Idle && fake == null) {
            Row(Modifier.align(Alignment.BottomCenter).fillMaxWidth().height(90.dp)) {
                Fake.entries.forEach { kind ->
                    Box(
                        Modifier
                            .weight(1f)
                            .fillMaxSize()
                            .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { runFake(kind) },
                    )
                }
            }
        }

        fake?.let { f ->
            FakeScreen(f, fakeProgress) { if (f == Fake.Offline) fake = null }
        }
    }

    if (showSettings) {
        SettingsDialog(s) { showSettings = false; s.save() }
    }
}

@Composable
fun Stars() {
    val t = rememberInfiniteTransition(label = "stars")
    val a by t.animateFloat(
        0.15f, 0.7f,
        infiniteRepeatable(tween(2400, easing = LinearEasing), RepeatMode.Reverse),
        label = "a",
    )
    Canvas(Modifier.fillMaxSize()) {
        for (i in 0 until 28) {
            val x = size.width * ((i * 37) % 100) / 100f
            val y = size.height * ((i * 53 + 11) % 100) / 100f
            val phase = if (i % 2 == 0) a else 0.85f - a
            drawCircle(Color.White.copy(alpha = phase), radius = (1 + i % 3).dp.toPx(), center = Offset(x, y))
        }
    }
}

@Composable
fun IdleView(s: Settings, method: Method, qr: ImageBitmap?) {
    val t = rememberInfiniteTransition(label = "idle")
    val rot by t.animateFloat(
        0f, 360f,
        infiniteRepeatable(tween(6000, easing = LinearEasing), RepeatMode.Restart),
        label = "rot",
    )
    val pulse by t.animateFloat(
        0.9f, 1.05f,
        infiniteRepeatable(tween(1400), RepeatMode.Reverse),
        label = "pulse",
    )
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(
            group(s.amountValue) + " " + s.currency,
            color = Color.White, fontSize = 52.sp, fontWeight = FontWeight.Bold, maxLines = 1,
        )
        Spacer(Modifier.height(16.dp))
        if (method == Method.Qr && qr != null) {
            Box(
                Modifier
                    .size((220 * pulse).dp)
                    .background(Color.White, RoundedCornerShape(22.dp))
                    .padding(14.dp),
            ) {
                Image(qr, contentDescription = null, filterQuality = FilterQuality.None, modifier = Modifier.fillMaxSize())
            }
        } else {
            Canvas(Modifier.size(220.dp)) {
                for (i in 0..2) {
                    val r = (45 + i * 28).dp.toPx()
                    drawCircle(Color.White.copy(alpha = 0.35f), radius = r, center = center, style = Stroke(1.5.dp.toPx()))
                    val ang = Math.toRadians((rot * (1 + i * 0.5f) - 90f).toDouble())
                    drawCircle(
                        Color.White, radius = 5.dp.toPx(),
                        center = Offset(center.x + (r * kotlin.math.cos(ang)).toFloat(), center.y + (r * kotlin.math.sin(ang)).toFloat()),
                    )
                }
                drawMethodIcon(method, center, 17.dp.toPx())
            }
        }
        Spacer(Modifier.height(16.dp))
        Text(method.hint, color = Color.White.copy(alpha = 0.8f), fontSize = 16.sp)
    }
}

fun androidx.compose.ui.graphics.drawscope.DrawScope.drawMethodIcon(method: Method, c: Offset, r: Float) {
    val stroke = Stroke(3.dp.toPx(), cap = StrokeCap.Round)
    when (method) {
        Method.Card -> for (i in 1..3) {
            val rr = r * (0.5f + i * 0.45f)
            drawArc(
                Color.White, startAngle = -40f, sweepAngle = 80f, useCenter = false,
                topLeft = Offset(c.x - rr - r, c.y - rr), size = Size(rr * 2, rr * 2), style = stroke,
            )
        }
        Method.Smile -> {
            drawCircle(Color.White, radius = r * 1.5f, center = c, style = stroke)
            drawCircle(Color.White, radius = 2.5.dp.toPx(), center = Offset(c.x - r * 0.5f, c.y - r * 0.4f))
            drawCircle(Color.White, radius = 2.5.dp.toPx(), center = Offset(c.x + r * 0.5f, c.y - r * 0.4f))
            drawArc(
                Color.White, startAngle = 20f, sweepAngle = 140f, useCenter = false,
                topLeft = Offset(c.x - r * 0.8f, c.y - r * 0.6f), size = Size(r * 1.6f, r * 1.6f), style = stroke,
            )
        }
        Method.Qr -> {}
    }
}

@Composable
fun ScanBox(method: Method, qr: ImageBitmap?, pop: Boolean) {
    val t = rememberInfiniteTransition(label = "scan")
    val sweep by t.animateFloat(
        -78f, 78f,
        infiniteRepeatable(tween(800), RepeatMode.Reverse),
        label = "sweep",
    )
    Box(Modifier.size(200.dp), contentAlignment = Alignment.Center) {
        if (method == Method.Smile) {
            Canvas(Modifier.size(120.dp)) {
                drawMethodIcon(Method.Smile, center, if (pop) 30.dp.toPx() else 24.dp.toPx())
            }
        } else if (qr != null) {
            Image(
                qr, contentDescription = null, filterQuality = FilterQuality.None,
                modifier = Modifier
                    .size(if (pop) 184.dp else 170.dp)
                    .background(Color.White, RoundedCornerShape(14.dp))
                    .padding(10.dp),
            )
        }
        Canvas(Modifier.fillMaxSize()) {
            val s = 36.dp.toPx()
            val pad = 6.dp.toPx()
            val st = Stroke(5.dp.toPx(), cap = StrokeCap.Round)
            val w = size.width
            val h = size.height
            fun corner(x: Float, y: Float, dx: Float, dy: Float) {
                drawLine(Color.White, Offset(x, y), Offset(x + dx * s, y), st.width, StrokeCap.Round)
                drawLine(Color.White, Offset(x, y), Offset(x, y + dy * s), st.width, StrokeCap.Round)
            }
            corner(pad, pad, 1f, 1f)
            corner(w - pad, pad, -1f, 1f)
            corner(pad, h - pad, 1f, -1f)
            corner(w - pad, h - pad, -1f, -1f)
            drawRect(
                Brush.verticalGradient(listOf(Color.Transparent, Color.White.copy(alpha = 0.9f), Color.Transparent)),
                topLeft = Offset(15.dp.toPx(), center.y + sweep.dp.toPx() - 12.dp.toPx()),
                size = Size(w - 30.dp.toPx(), 24.dp.toPx()),
            )
        }
    }
}

@Composable
fun Spinner() {
    val t = rememberInfiniteTransition(label = "spin")
    val a by t.animateFloat(
        0f, 360f,
        infiniteRepeatable(tween(900, easing = LinearEasing), RepeatMode.Restart),
        label = "a",
    )
    Canvas(Modifier.size(140.dp)) {
        val r = 66.dp.toPx()
        drawArc(
            Color.White, startAngle = a, sweepAngle = 270f, useCenter = false,
            topLeft = Offset(center.x - r, center.y - r), size = Size(2 * r, 2 * r),
            style = Stroke(8.dp.toPx(), cap = StrokeCap.Round),
        )
    }
}

@Composable
fun Dots() {
    val t = rememberInfiniteTransition(label = "dots")
    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        for (i in 0..2) {
            val v by t.animateFloat(
                0.35f, 1f,
                infiniteRepeatable(tween(500, delayMillis = i * 150), RepeatMode.Reverse),
                label = "d$i",
            )
            Box(Modifier.size(14.dp).alpha(v).background(Color.White, CircleShape))
        }
    }
}

@Composable
fun ChargingRing(progress: Float, red: Boolean, text: String, label: String) {
    val color = if (red) Color(0xFFFF4D4D) else Color.White
    Box(Modifier.size(200.dp), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val stroke = 10.dp.toPx()
            val inset = stroke / 2
            drawArc(
                Color.White.copy(alpha = 0.2f), 0f, 360f, false,
                topLeft = Offset(inset, inset), size = Size(size.width - stroke, size.height - stroke), style = Stroke(stroke),
            )
            drawArc(
                color, -90f, 360f * progress, false,
                topLeft = Offset(inset, inset), size = Size(size.width - stroke, size.height - stroke),
                style = Stroke(stroke, cap = StrokeCap.Round),
            )
        }
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(text, color = color, fontSize = 26.sp, fontWeight = FontWeight.Bold, maxLines = 1)
            Text(label, color = color.copy(alpha = 0.7f), fontSize = 12.sp)
        }
    }
}

@Composable
fun DoneView(failed: Boolean, joke: String) {
    val pop = remember { Animatable(0.3f) }
    LaunchedEffect(Unit) { pop.animateTo(1f, tween(500)) }
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Canvas(Modifier.size(110.dp)) {
            val r = size.minDimension / 2 * pop.value
            drawCircle(Color.White, radius = r, center = center)
            val st = Stroke(10.dp.toPx() * pop.value, cap = StrokeCap.Round)
            val ink = Color(0xFF1B1450)
            if (failed) {
                val d = r * 0.35f
                drawLine(ink, Offset(center.x - d, center.y - d), Offset(center.x + d, center.y + d), st.width, StrokeCap.Round)
                drawLine(ink, Offset(center.x + d, center.y - d), Offset(center.x - d, center.y + d), st.width, StrokeCap.Round)
            } else {
                drawLine(ink, Offset(center.x - r * 0.4f, center.y), Offset(center.x - r * 0.1f, center.y + r * 0.3f), st.width, StrokeCap.Round)
                drawLine(ink, Offset(center.x - r * 0.1f, center.y + r * 0.3f), Offset(center.x + r * 0.42f, center.y - r * 0.3f), st.width, StrokeCap.Round)
            }
        }
        Spacer(Modifier.height(36.dp))
        Text(joke, color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
        Spacer(Modifier.height(20.dp))
        Text("Это розыгрыш. Деньги не списаны.", color = Color.White.copy(alpha = 0.75f), fontSize = 13.sp)
    }
}

@Composable
fun FakeScreen(kind: Fake, progress: Float, onTap: () -> Unit) {
    Box(
        Modifier
            .fillMaxSize()
            .background(if (kind == Fake.Offline) Color.Black.copy(alpha = 0.92f) else Color.Black)
            .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { onTap() },
        contentAlignment = Alignment.Center,
    ) {
        when (kind) {
            Fake.Reboot -> {}
            Fake.Update -> Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text("Обновление ПО", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(22.dp))
                Box(Modifier.width(220.dp).height(6.dp).background(Color.White.copy(alpha = 0.2f), RoundedCornerShape(3.dp))) {
                    Box(Modifier.fillMaxSize().padding(end = (220 * (1 - progress)).dp).background(Color.White, RoundedCornerShape(3.dp)))
                }
                Spacer(Modifier.height(16.dp))
                Text("${(progress * 100).toInt()}%", color = Color.White, fontSize = 16.sp)
                Spacer(Modifier.height(8.dp))
                Text("Не выключайте терминал", color = Color.White.copy(alpha = 0.6f), fontSize = 12.sp)
            }
            Fake.Offline -> Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Spinner()
                Spacer(Modifier.height(20.dp))
                Text("Нет связи", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(8.dp))
                Text("Проверка подключения…", color = Color.White.copy(alpha = 0.7f), fontSize = 15.sp)
                Spacer(Modifier.height(12.dp))
                Text("тап — закрыть", color = Color.White.copy(alpha = 0.4f), fontSize = 12.sp)
            }
        }
    }
}

@Composable
fun <T> Chips(options: List<T>, selected: Int, label: (T) -> String, onSelect: (Int) -> Unit) {
    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        options.forEachIndexed { i, o ->
            Text(
                label(o),
                color = if (i == selected) Color.Black else Color.White,
                fontSize = 13.sp,
                modifier = Modifier
                    .background(if (i == selected) Color.White else Color.White.copy(alpha = 0.15f), RoundedCornerShape(50))
                    .clickable { onSelect(i) }
                    .padding(horizontal = 12.dp, vertical = 8.dp),
            )
        }
    }
}

@Composable
fun SettingsDialog(s: Settings, onClose: () -> Unit) {
    AlertDialog(
        onDismissRequest = onClose,
        confirmButton = { TextButton(onClick = onClose) { Text("Готово") } },
        dismissButton = { TextButton(onClick = { s.reset() }) { Text("Сбросить") } },
        title = { Text("Настройки") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                TextField(
                    value = s.amount,
                    onValueChange = { s.amount = it.filter(Char::isDigit).take(12) },
                    label = { Text("Сумма") },
                    singleLine = true,
                )
                Text("Валюта", fontSize = 12.sp)
                Chips(currencies, currencies.indexOf(s.currency).coerceAtLeast(0), { it }) { s.currency = currencies[it] }
                Text("Способ оплаты", fontSize = 12.sp)
                Chips(Method.entries, s.method, { it.title }) { s.method = it }
                Text("Финал (в любом случае показывается, что это розыгрыш)", fontSize = 12.sp)
                Chips(listOf("Шутка", "Ошибка"), s.mode, { it }) { s.mode = it }
                Text("Тема", fontSize = 12.sp)
                Chips(themes, s.theme, { it.first }) { s.theme = it }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Звёзды на фоне", Modifier.weight(1f)); Switch(s.stars, { s.stars = it })
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Звук", Modifier.weight(1f)); Switch(s.sound, { s.sound = it })
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Вибрация", Modifier.weight(1f)); Switch(s.haptics, { s.haptics = it })
                }
                Text("Скорость анимации ×%.1f".format(s.speed), fontSize = 12.sp)
                Slider(s.speed, { s.speed = it }, valueRange = 0.5f..2f)
                Text("Пауза перед финалом +%.1f с".format(s.hold), fontSize = 12.sp)
                Slider(s.hold, { s.hold = it }, valueRange = 0f..3f)
            }
        },
    )
}
