import SwiftUI

/// Скрытые «служебные» экраны терминала: перезагрузка, обновление ПО, нет связи.
enum FakeKind: CaseIterable {
    case reboot, update, offline
}

/// Заставка при запуске: орбиты дорисовываются, потом появляется название.
struct SplashView: View {
    let name: String
    @State private var go = false

    var body: some View {
        ZStack {
            Color.black.ignoresSafeArea()
            VStack(spacing: 28) {
                ZStack {
                    ForEach(0..<3) { i in
                        Circle().trim(from: 0, to: go ? 1 : 0)
                            .stroke(.white.opacity(0.85 - Double(i) * 0.2),
                                    style: StrokeStyle(lineWidth: 2.5, lineCap: .round))
                            .frame(width: 70 + CGFloat(i) * 46, height: 70 + CGFloat(i) * 46)
                            .rotationEffect(.degrees(go ? Double(i) * 140 - 90 : -90))
                            .animation(.easeOut(duration: 1.1 + Double(i) * 0.3), value: go)
                    }
                    Circle().fill(.white).frame(width: 18, height: 18)
                        .scaleEffect(go ? 1 : 0)
                        .animation(.spring(duration: 0.8, bounce: 0.5).delay(0.4), value: go)
                }.frame(height: 200)
                Text(name)
                    .font(.system(size: 30, weight: .bold, design: .rounded))
                    .foregroundStyle(.white)
                    .opacity(go ? 1 : 0).offset(y: go ? 0 : 12)
                    .animation(.easeOut(duration: 0.8).delay(0.7), value: go)
            }
        }
        .onAppear { go = true }
    }
}

struct FakeScreen: View {
    let kind: FakeKind
    let progress: Double
    @State private var spin = false

    var body: some View {
        switch kind {
        case .reboot:
            Color.black.ignoresSafeArea()
        case .update:
            ZStack {
                Color.black.ignoresSafeArea()
                VStack(spacing: 22) {
                    Image(systemName: "arrow.down.circle").font(.system(size: 56, weight: .light))
                    Text("Обновление ПО").font(.title3.bold())
                    ProgressView(value: progress).tint(.white).frame(width: 220)
                    Text("\(Int(progress * 100))%").font(.callout).monospacedDigit()
                    Text("Не выключайте терминал").font(.caption).opacity(0.6)
                }.foregroundStyle(.white)
            }
        case .offline:
            ZStack {
                Color.black.opacity(0.92).ignoresSafeArea()
                VStack(spacing: 20) {
                    Circle().trim(from: 0, to: 0.75)
                        .stroke(.white, style: StrokeStyle(lineWidth: 5, lineCap: .round))
                        .frame(width: 70, height: 70)
                        .rotationEffect(.degrees(spin ? 360 : 0))
                        .animation(.linear(duration: 1).repeatForever(autoreverses: false), value: spin)
                    Text("Нет связи").font(.title3.bold())
                    Text("Проверка подключения…").font(.callout).opacity(0.7)
                    Text("тап — закрыть").font(.caption).opacity(0.4).padding(.top, 8)
                }.foregroundStyle(.white)
            }.onAppear { spin = true }
        }
    }
}
