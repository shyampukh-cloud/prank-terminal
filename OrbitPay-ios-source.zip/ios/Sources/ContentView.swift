import SwiftUI
import AudioToolbox
import CoreImage.CIFilterBuiltins

enum Phase { case idle, scan, request, waiting, charging, done }
enum Method: Int, CaseIterable {
    case card, smile, qr
    var title: String { ["Карта", "Улыбка", "QR"][rawValue] }
    var icon: String { ["wave.3.right", "face.smiling", "qrcode"][rawValue] }
    var hint: String {
        ["Коснитесь экрана для оплаты", "Коснитесь и улыбнитесь", "Коснитесь, когда QR отсканируют"][rawValue]
    }
}

/// Orbit Pay: розыгрыш-имитация терминала. Деньги не списываются, надпись о розыгрыше нельзя убрать.
struct ContentView: View {
    @AppStorage("amount") private var amount = "199"
    @AppStorage("sound") private var sound = true
    @AppStorage("haptics") private var haptics = true
    @AppStorage("speed") private var speed = 1.0
    @AppStorage("currency") private var currency = "₽"
    @AppStorage("palette") private var palette = 0
    @AppStorage("mode") private var mode = 0
    @AppStorage("hold") private var hold = 0.0
    @AppStorage("method") private var methodRaw = 0
    @AppStorage("stars") private var stars = true

    @State private var phase: Phase = .idle
    @State private var splash = true
    @State private var fake: FakeKind?
    @State private var fakeProgress = 0.0
    @State private var logoTaps = 0
    @State private var lastLogoTap = Date.distantPast
    @State private var settings = false
    @State private var spin = false
    @State private var pulse = false
    @State private var orbit = false
    @State private var sweep = false
    @State private var twinkle = false
    @State private var pop = false
    @State private var ring: CGFloat = 0
    @State private var ringColor = Color.white
    @State private var chargeLabel = "оплата"
    @State private var burst = false
    @State private var joke = Self.jokes[0]
    @State private var failed = false
    @State private var willFail = false
    @State private var qrImage: UIImage?
    @State private var qrToken = 0
    @State private var counter = 0.0
    @State private var shakeX: CGFloat = 0

    var method: Method { Method(rawValue: methodRaw) ?? .card }

    static let palettes: [(String, [Color])] = [
        ("Космос", [Color(red: 0.04, green: 0.04, blue: 0.16), Color(red: 0.28, green: 0.12, blue: 0.5)]),
        ("Океан", [Color(red: 0.0, green: 0.12, blue: 0.3), Color(red: 0.0, green: 0.5, blue: 0.6)]),
        ("Закат", [Color(red: 0.3, green: 0.05, blue: 0.25), Color(red: 0.95, green: 0.45, blue: 0.3)]),
        ("Мята", [Color(red: 0.1, green: 0.55, blue: 0.4), Color(red: 0.55, green: 0.9, blue: 0.7)]),
        ("Лес", [Color(red: 0.02, green: 0.15, blue: 0.1), Color(red: 0.1, green: 0.45, blue: 0.25)]),
        ("Ночь", [Color(red: 0.02, green: 0.02, blue: 0.04), Color(red: 0.15, green: 0.15, blue: 0.2)]),
    ]

    // Любой финал содержит явное указание, что это розыгрыш.
    static let jokes = [
        "Оплата успешна…\nшутка, это пранк",
        "Это был пранк\nДеньги никуда не ушли",
        "Недостаточно мемов на карте\nпранк",
        "Транзакция одобрена\nмамой, но не банком (пранк)",
    ]
    static let smileJokes = [
        "Улыбка распознана\nСтоимость: один анекдот (пранк)",
        "Улыбка принята, оплата нет\nэто пранк",
    ]
    static let qrJokes = [
        "QR-код оказался\nрецептом борща (пранк)",
        "QR отсканирован\nи отправлен в рофл (пранк)",
    ]
    static let failTexts = [
        "Карта заблокирована\nобратитесь к маме (пранк)",
        "Ошибка 418\nя чайник (пранк)",
        "Банк в отпуске\nпопробуйте позже (пранк)",
    ]
    static let currencies = ["₽", "$", "€", "₸", "₴", "Br"]

    var amountValue: Double { Double(Int(amount.filter(\.isNumber)) ?? 0) }

    /// 1500 -> «1 500» (узкий неразрывный пробел между разрядами).
    static func group(_ n: Int) -> String {
        var out = ""
        for (i, ch) in String(n).reversed().enumerated() {
            if i > 0 && i % 3 == 0 { out.append("\u{202F}") }
            out.append(ch)
        }
        return String(out.reversed())
    }
    var shownAmount: String { Self.group(Int(amountValue)) }

    func newQR() {
        let alphabet = Array("ABCDEFGHJKLMNPQRSTUVWXYZ23456789")
        let code = String((0..<16).map { _ in alphabet.randomElement()! })
        let f = CIFilter.qrCodeGenerator()
        f.message = Data("ORBIT-PRANK-\(code)".utf8)
        f.correctionLevel = "M"
        guard let out = f.outputImage?.transformed(by: CGAffineTransform(scaleX: 12, y: 12)),
              let cg = CIContext().createCGImage(out, from: out.extent) else { return }
        withAnimation(.spring(duration: 0.4)) { qrImage = UIImage(cgImage: cg); qrToken += 1 }
    }

    var body: some View {
        ZStack {
            LinearGradient(colors: Self.palettes[min(palette, Self.palettes.count - 1)].1,
                           startPoint: .top, endPoint: .bottom).ignoresSafeArea()
            if stars { starfield }
            VStack(spacing: 8) {
                Text("Orbit Pay")
                    .font(.system(size: 22, weight: .bold, design: .rounded))
                    .foregroundStyle(.white.opacity(0.95))
                    .padding(.vertical, 6).padding(.horizontal, 20)
                    .contentShape(Rectangle())
                    .onTapGesture { logoTap() }
                    .padding(.top, 12)
                Text("пранк-терминал, не настоящий")
                    .font(.footnote).foregroundStyle(.white.opacity(0.7))
                Spacer()
                content
                Spacer()
                if phase == .idle { footer }
            }
            .padding()
        }
        .contentShape(Rectangle())
        .onTapGesture {
            if phase == .idle && !settings { start() } else if phase == .done { reset() }
        }
        .gesture(DragGesture(minimumDistance: 50).onEnded { v in
            // Свайп влево/вправо по экрану листает способ оплаты (Карта → Улыбка → QR).
            guard phase == .idle, !settings, fake == nil, abs(v.translation.width) > abs(v.translation.height) else { return }
            let n = Method.allCases.count
            let next = (methodRaw + (v.translation.width < 0 ? 1 : n - 1)) % n
            withAnimation(.spring(duration: 0.3)) { methodRaw = next }
            if haptics { UISelectionFeedbackGenerator().selectionChanged() }
        })
        .overlay(alignment: .bottom) { bottomZones }
        .overlay {
            if let f = fake {
                FakeScreen(kind: f, progress: fakeProgress)
                    .transition(.opacity)
                    .onTapGesture { if f == .offline { withAnimation { fake = nil } } }
            }
        }
        .overlay {
            if splash { SplashView(name: "Orbit Pay").transition(.opacity) }
        }
        .onReceive(Timer.publish(every: 4, on: .main, in: .common).autoconnect()) { _ in
            if method == .qr && phase == .idle && !settings { newQR() }
        }
        .statusBarHidden(true)
        .sheet(isPresented: $settings) { settingsSheet }
        .onAppear {
            twinkle = true
            newQR()
            DispatchQueue.main.asyncAfter(deadline: .now() + 2.6) {
                withAnimation(.easeOut(duration: 0.5)) { splash = false }
            }
        }
    }

    /// Три невидимые зоны в нижней части экрана: перезагрузка, обновление, нет связи.
    var bottomZones: some View {
        HStack(spacing: 0) {
            ForEach(Array(FakeKind.allCases.enumerated()), id: \.offset) { _, kind in
                Color.clear.contentShape(Rectangle()).frame(height: 90)
                    .onTapGesture { runFake(kind) }
            }
        }
        .allowsHitTesting(phase == .idle && !settings && fake == nil && !splash)
    }

    /// Пять быстрых тапов по названию открывают настройки.
    func logoTap() {
        let now = Date()
        logoTaps = now.timeIntervalSince(lastLogoTap) < 1.2 ? logoTaps + 1 : 1
        lastLogoTap = now
        if logoTaps >= 5 {
            logoTaps = 0
            if haptics { UIImpactFeedbackGenerator(style: .rigid).impactOccurred() }
            settings = true
        }
    }

    func runFake(_ kind: FakeKind) {
        if haptics { UIImpactFeedbackGenerator(style: .light).impactOccurred() }
        fakeProgress = 0
        withAnimation(.easeInOut(duration: 0.3)) { fake = kind }
        switch kind {
        case .reboot:
            DispatchQueue.main.asyncAfter(deadline: .now() + 1.4) { finishReboot() }
        case .update:
            var p = 0.0
            Timer.scheduledTimer(withTimeInterval: 0.15, repeats: true) { t in
                p = min(1, p + Double.random(in: 0.004...0.03))
                fakeProgress = p
                if p >= 1 {
                    t.invalidate()
                    DispatchQueue.main.asyncAfter(deadline: .now() + 0.6) { finishReboot() }
                }
            }
        case .offline:
            break
        }
    }

    func finishReboot() {
        splash = true
        withAnimation(.easeInOut(duration: 0.3)) { fake = nil }
        DispatchQueue.main.asyncAfter(deadline: .now() + 2.6) {
            withAnimation(.easeOut(duration: 0.5)) { splash = false }
        }
    }

    var starfield: some View {
        GeometryReader { g in
            ForEach(0..<28, id: \.self) { i in
                Circle().fill(.white)
                    .frame(width: CGFloat(2 + i % 3), height: CGFloat(2 + i % 3))
                    .position(x: g.size.width * CGFloat((i * 37) % 100) / 100,
                              y: g.size.height * CGFloat((i * 53 + 11) % 100) / 100)
                    .opacity(twinkle ? 0.15 : 0.7)
                    .animation(.easeInOut(duration: 1.2 + Double(i % 5) * 0.4).repeatForever().delay(Double(i % 7) * 0.2), value: twinkle)
            }
        }.ignoresSafeArea().allowsHitTesting(false)
    }

    var footer: some View {
        HStack(spacing: 6) {
            Image(systemName: "cellularbars")
            Text("Демо-режим")
            Spacer()
            Text(Date.now, style: .time)
        }.font(.caption2).foregroundStyle(.white.opacity(0.5))
    }

    @ViewBuilder var content: some View {
        switch phase {
        case .idle:
            VStack(spacing: 16) {
                Text("\(shownAmount) \(currency)")
                    .font(.system(size: 60, weight: .bold, design: .rounded))
                    .minimumScaleFactor(0.5).lineLimit(1).foregroundStyle(.white)
                if method == .qr { qrCard } else {
                    ZStack {
                        ForEach(0..<3) { i in
                            Circle().stroke(.white.opacity(0.35), lineWidth: 1.5)
                                .frame(width: 90 + CGFloat(i) * 56, height: 90 + CGFloat(i) * 56)
                            Circle().fill(.white)
                                .frame(width: 10, height: 10)
                                .offset(y: -(45 + CGFloat(i) * 28))
                                .rotationEffect(.degrees(orbit ? 360 : 0))
                                .animation(.linear(duration: 4 + Double(i) * 2).repeatForever(autoreverses: false), value: orbit)
                        }
                        Image(systemName: method.icon).font(.system(size: 34)).foregroundStyle(.white)
                            .symbolEffect(.pulse, options: .repeating)
                    }.frame(height: 220).onAppear { orbit = true }
                }
                Text(method.hint).foregroundStyle(.white.opacity(0.8))
            }
        case .scan:
            VStack(spacing: 22) {
                scanView
                Text(method == .smile ? "Улыбнитесь в камеру" : "QR-код считан…")
                    .font(.callout).foregroundStyle(.white.opacity(0.9))
            }
        case .request:
            VStack(spacing: 20) {
                Circle().trim(from: 0, to: 0.75)
                    .stroke(.white, style: StrokeStyle(lineWidth: 8, lineCap: .round))
                    .frame(width: 140, height: 140)
                    .rotationEffect(.degrees(spin ? 360 : 0))
                    .animation(.linear(duration: 0.9).repeatForever(autoreverses: false), value: spin)
                Text("Передаю запрос…").font(.callout).foregroundStyle(.white.opacity(0.9))
            }
        case .waiting:
            VStack(spacing: 28) {
                HStack(spacing: 12) {
                    ForEach(0..<3) { i in
                        Circle().fill(.white).frame(width: 14, height: 14)
                            .scaleEffect(pulse ? 1.5 : 0.7).opacity(pulse ? 1 : 0.35)
                            .animation(.easeInOut(duration: 0.5).repeatForever().delay(Double(i) * 0.15), value: pulse)
                    }
                }
                Text(willFail ? "Банк не отвечает…" : "Жду ответа…")
                    .font(.callout).foregroundStyle(.white.opacity(0.9))
            }
        case .charging:
            ZStack {
                Circle().stroke(.white.opacity(0.2), lineWidth: 10)
                Circle().trim(from: 0, to: ring)
                    .stroke(ringColor, style: StrokeStyle(lineWidth: 10, lineCap: .round))
                    .rotationEffect(.degrees(-90))
                VStack(spacing: 2) {
                    HStack(spacing: 4) {
                        CountingText(value: counter, format: Self.group)
                        Text(currency)
                    }.font(.system(size: 28, weight: .bold, design: .rounded)).minimumScaleFactor(0.5).lineLimit(1)
                    Text(chargeLabel).font(.caption).opacity(0.7)
                }.foregroundStyle(ringColor).padding(.horizontal, 24)
            }.frame(width: 200, height: 200).offset(x: shakeX)
        case .done:
            VStack(spacing: 20) {
                ZStack {
                    ForEach(0..<24) { i in
                        Capsule().fill(.white.opacity(0.9))
                            .frame(width: 3, height: burst ? 6 : 18)
                            .offset(y: burst ? -150 : -70)
                            .rotationEffect(.degrees(Double(i) * 15))
                            .opacity(burst ? 0 : 1)
                    }
                    Image(systemName: failed ? "xmark.circle.fill" : "checkmark.circle.fill").font(.system(size: 110)).foregroundStyle(.white)
                        .scaleEffect(burst ? 1 : 0.3)
                }.frame(height: 220)
                Text(joke).multilineTextAlignment(.center).font(.title2.bold()).foregroundStyle(.white)
                Text("Это розыгрыш. Деньги не списаны.")
                    .font(.footnote).foregroundStyle(.white.opacity(0.75))
            }.offset(x: shakeX)
        }
    }

    var qrCard: some View {
        Group {
            if let img = qrImage {
                Image(uiImage: img).interpolation(.none).resizable().scaledToFit()
                    .padding(14).background(.white, in: RoundedRectangle(cornerRadius: 22))
                    .frame(width: 220, height: 220)
                    .shadow(color: .white.opacity(pulse ? 0.55 : 0.1), radius: pulse ? 26 : 8)
                    .scaleEffect(pulse ? 1.03 : 1)
                    .animation(.easeInOut(duration: 1.4).repeatForever(), value: pulse)
                    .id(qrToken)
                    .transition(.scale.combined(with: .opacity))
            }
        }.frame(height: 220).onAppear { pulse = true }
    }

    /// Рамка сканера с бегущей линией: лицо для «улыбки», QR-картинка для QR.
    var scanView: some View {
        ZStack {
            if method == .smile {
                Image(systemName: pop ? "face.smiling.inverse" : "face.dashed")
                    .font(.system(size: 110, weight: .light)).foregroundStyle(.white)
                    .scaleEffect(pop ? 1.1 : 1)
                    .animation(.spring(duration: 0.5, bounce: 0.5), value: pop)
            } else if let img = qrImage {
                Image(uiImage: img).interpolation(.none).resizable().scaledToFit()
                    .padding(10).background(.white, in: RoundedRectangle(cornerRadius: 14))
                    .frame(width: 170, height: 170)
                    .scaleEffect(pop ? 1.08 : 1)
                    .animation(.spring(duration: 0.4, bounce: 0.5), value: pop)
            }
            ForEach(0..<4) { i in
                CornerShape().stroke(.white, style: StrokeStyle(lineWidth: 5, lineCap: .round))
                    .frame(width: 36, height: 36)
                    .rotationEffect(.degrees(Double(i) * 90))
                    .offset(x: i == 0 || i == 3 ? -85 : 85, y: i < 2 ? -85 : 85)
            }
            Rectangle()
                .fill(LinearGradient(colors: [.clear, .white.opacity(0.9), .clear], startPoint: .top, endPoint: .bottom))
                .frame(width: 170, height: 24)
                .offset(y: sweep ? 78 : -78)
                .animation(.easeInOut(duration: 0.8).repeatForever(autoreverses: true), value: sweep)
        }.frame(width: 200, height: 200)
    }

    var settingsSheet: some View {
        NavigationStack {
            Form {
                Section("Сумма") {
                    TextField("Сумма", text: $amount).keyboardType(.numberPad)
                    Text("На экране: \(shownAmount) \(currency)").foregroundStyle(.secondary)
                    Picker("Валюта", selection: $currency) {
                        ForEach(Self.currencies, id: \.self) { Text($0).tag($0) }
                    }.pickerStyle(.segmented)
                }
                Section("Способ оплаты") {
                    Picker("Способ", selection: $methodRaw) {
                        ForEach(Method.allCases, id: \.rawValue) { Text($0.title).tag($0.rawValue) }
                    }.pickerStyle(.segmented)
                }
                Section("Финал") {
                    Picker("Режим", selection: $mode) {
                        Text("Шутка").tag(0)
                        Text("Ошибка").tag(1)
                    }.pickerStyle(.segmented)
                    Text("В любом финале показывается, что это розыгрыш.").font(.caption).foregroundStyle(.secondary)
                }
                Section("Тема") {
                    Picker("Тема", selection: $palette) {
                        ForEach(0..<Self.palettes.count, id: \.self) { Text(Self.palettes[$0].0).tag($0) }
                    }.pickerStyle(.menu)
                    Toggle("Звёзды на фоне", isOn: $stars)
                }
                Section("Эффекты") {
                    Toggle("Звук", isOn: $sound)
                    Toggle("Вибрация", isOn: $haptics)
                }
                Section("Скорость анимации") {
                    Slider(value: $speed, in: 0.5...2)
                    Text(String(format: "×%.1f", speed)).foregroundStyle(.secondary)
                }
                Section("Пауза перед финалом") {
                    Slider(value: $hold, in: 0...3)
                    Text(String(format: "+%.1f с", hold)).foregroundStyle(.secondary)
                }
                Section {
                    Button("Сбросить настройки", role: .destructive) {
                        amount = "199"; sound = true; haptics = true; speed = 1; currency = "₽"
                        palette = 0; mode = 0; hold = 0; methodRaw = 0; stars = true
                    }
                }
            }
            .navigationTitle("Настройки")
            .toolbar { Button("Готово") { settings = false } }
        }
        .presentationDetents([.large])
    }

    func go(_ p: Phase, after delay: Double, _ action: @escaping () -> Void = {}) {
        DispatchQueue.main.asyncAfter(deadline: .now() + delay / speed) {
            withAnimation(.easeInOut(duration: 0.25)) { phase = p }
            action()
        }
    }

    func start() {
        if haptics { UIImpactFeedbackGenerator(style: .medium).impactOccurred() }
        if sound { AudioServicesPlaySystemSound(1104) }
        willFail = mode == 1
        failed = false
        ring = 0; counter = 0; ringColor = .white; chargeLabel = "оплата"
        burst = false; spin = false; sweep = false; pop = false
        let scanTime = method == .card ? 0.0 : 2.4
        let jit = Double.random(in: 0.9...1.25)

        if method == .card {
            withAnimation(.easeInOut(duration: 0.25)) { phase = .request }
            DispatchQueue.main.async { spin = true }
        } else {
            withAnimation(.easeInOut(duration: 0.25)) { phase = .scan }
            DispatchQueue.main.async { sweep = true }
            go(.scan, after: 1.7) { pop = true; if haptics { UIImpactFeedbackGenerator(style: .light).impactOccurred() } }
            go(.request, after: scanTime) { spin = false; DispatchQueue.main.async { spin = true } }
        }

        let waitAt = scanTime + 1.6 * jit
        let chargeAt = waitAt + 1.2 * jit
        go(.waiting, after: waitAt) { pulse = false; DispatchQueue.main.async { pulse = true } }

        go(.charging, after: chargeAt) {
            if willFail {
                counter = amountValue
                withAnimation(.easeOut(duration: 0.9 / speed)) { ring = CGFloat.random(in: 0.25...0.65) }
                DispatchQueue.main.asyncAfter(deadline: .now() + 1.2 / speed) {
                    withAnimation(.easeInOut(duration: 0.2)) { ringColor = .red; chargeLabel = "ошибка" }
                    if haptics { UINotificationFeedbackGenerator().notificationOccurred(.warning) }
                    shake()
                }
            } else {
                withAnimation(.easeInOut(duration: 1.2 / speed)) { ring = 1; counter = amountValue }
            }
        }

        let doneAt = chargeAt + (willFail ? 2.2 : 1.3) + hold
        go(.done, after: doneAt) {
            failed = willFail
            let pool = Self.jokes + (method == .smile ? Self.smileJokes : method == .qr ? Self.qrJokes : [])
            joke = failed ? Self.failTexts.randomElement()! : pool.randomElement()!
            if sound { AudioServicesPlaySystemSound(failed ? 1073 : 1407) }
            if haptics { UINotificationFeedbackGenerator().notificationOccurred(failed ? .error : .success) }
            withAnimation(.spring(duration: 0.7, bounce: 0.4)) { burst = true }
            if failed { shake() }
        }
    }

    func shake() {
        shakeX = 0
        withAnimation(.linear(duration: 0.07).repeatCount(8, autoreverses: true)) { shakeX = 12 }
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.6) { shakeX = 0 }
    }

    func reset() { withAnimation { phase = .idle } }
}

struct CornerShape: Shape {
    func path(in rect: CGRect) -> Path {
        var p = Path()
        p.move(to: CGPoint(x: rect.minX, y: rect.maxY))
        p.addLine(to: CGPoint(x: rect.minX, y: rect.minY))
        p.addLine(to: CGPoint(x: rect.maxX, y: rect.minY))
        return p
    }
}

struct CountingText: View, Animatable {
    var value: Double
    var format: (Int) -> String
    var animatableData: Double {
        get { value }
        set { value = newValue }
    }
    var body: some View { Text(format(Int(value))) }
}
