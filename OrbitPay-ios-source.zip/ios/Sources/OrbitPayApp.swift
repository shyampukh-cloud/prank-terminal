import SwiftUI

@main
struct OrbitPayApp: App {
    var body: some Scene {
        WindowGroup { ContentView() }
    }
}
